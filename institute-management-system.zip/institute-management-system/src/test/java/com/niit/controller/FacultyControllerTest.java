package com.niit.controller;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.context.MessageSource;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;

import com.niit.institute.controller.FacultyController;
import com.niit.institute.model.Faculty;
import com.niit.institute.service.FacultyService;


public class FacultyControllerTest {


	  @Mock
	   FacultyService service;
	     
	    @Mock
	    MessageSource message;
	     
	    @InjectMocks
	    FacultyController facultyController;
	    
	    @Spy
	    List<Faculty> facultys = new ArrayList<Faculty>();
	 
	    @Spy
	    ModelMap model;
	     
	    @Mock
	    BindingResult result;
	     
	    @Before
	    public void setUp(){
	        MockitoAnnotations.initMocks(this);
	        facultys = getFacultyList();
	    }
	    
	    @Test
	    public void listEmployees(){
	        when(service.getFacultys()).thenReturn(facultys);
	        Assert.assertEquals(facultyController.listFacultys(model), "list-faculty");
	        Assert.assertEquals(model.get("facultys"), facultys);
	        verify(service, atLeastOnce()).getFacultys();
	    }
	    
	    
	    @Test
	    public void newCustomer(){
	        Assert.assertEquals(facultyController.showFormForAdd(model), "faculty-form");
	        Assert.assertNotNull(model.get("faculty"));
	       Assert.assertEquals(((Faculty)model.get("faculty")).getId(), 0);
	    }
		    
	    @Test
	    public void saveCustomer(){
	        when(result.hasErrors()).thenReturn(false);
	        //when(service.isEmployeeSsnUnique(anyInt(), anyString())).thenReturn(true);
	        doNothing().when(service).saveFaculty(any(Faculty.class));
	        Assert.assertEquals(facultyController.saveFaculty(facultys.get(0)), "redirect:/faculty/list");
	   	     
	    }
	    
	    @Test
	    public void editStudent(){
	    	Faculty cust = facultys.get(0);
	        when(service.getFaculty(anyInt())).thenReturn(cust);
	        Assert.assertEquals(facultyController.showFormForUpdate(anyInt(), model),"faculty-form");
	        Assert.assertNotNull(model.get("faculty"));
	     //   Assert.assertTrue((Boolean)model.get("edit"));
	        Assert.assertEquals(((Faculty)model.get("faculty")).getId(), 3);
	    }
	    
	      	  @Test
	    	    public void deleteEmployee(){
	    	        doNothing().when(service).deleteFaculty(anyInt());
	    	        Assert.assertEquals(facultyController.deleteFaculty(123), "redirect:/faculty/list");
	    	    }
	    
	    
		public List<Faculty> getFacultyList() {
			Faculty c1 = new Faculty();
			Faculty c2 = new Faculty();
	        c1.setId(3);
	        c1.setFirstname("rajashekar");
	        c1.setLastname("sharma");
	        c1.setEmail("rajmatti@gmail.com");
	        
	        c2.setId(4);
	        c2.setFirstname("navin");
	        c2.setLastname("sharma");
	        c2.setEmail("navi@gmail.com");
	     
			facultys.add(c1);
			facultys.add(c2);
			
			return facultys;
		}

}
