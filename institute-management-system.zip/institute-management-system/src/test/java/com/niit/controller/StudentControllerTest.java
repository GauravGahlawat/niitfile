package com.niit.controller;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.context.MessageSource;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;

import com.niit.institute.controller.StudentController;
import com.niit.institute.model.Student;
import com.niit.institute.service.StudentService;


public class StudentControllerTest {


	  @Mock
	   StudentService service;
	     
	    @Mock
	    MessageSource message;
	     
	    @InjectMocks
	    StudentController studentController;
	    
	    @Spy
	    List<Student> students = new ArrayList<Student>();
	 
	    @Spy
	    ModelMap model;
	     
	    @Mock
	    BindingResult result;
	     
	    @Before
	    public void setUp(){
	        MockitoAnnotations.initMocks(this);
	        students = getStudentList();
	    }
	    
	    @Test
	    public void listEmployees(){
	        when(service.getStudents()).thenReturn(students);
	        Assert.assertEquals(studentController.listStudents(model), "list-students");
	        Assert.assertEquals(model.get("students"), students);
	        verify(service, atLeastOnce()).getStudents();
	    }
	    
	    
	    @Test
	    public void newCustomer(){
	        Assert.assertEquals(studentController.showFormForAdd(model), "student-form");
	        Assert.assertNotNull(model.get("student"));
	       Assert.assertEquals(((Student)model.get("student")).getId(), 0);
	    }
		    
	    @Test
	    public void saveCustomer(){
	        when(result.hasErrors()).thenReturn(false);
	        //when(service.isEmployeeSsnUnique(anyInt(), anyString())).thenReturn(true);
	        doNothing().when(service).saveStudent(any(Student.class));
	        Assert.assertEquals(studentController.saveStudent(students.get(0)), "redirect:/student/list");
	   	     
	    }
	    
	    @Test
	    public void editStudent(){
	    	Student cust = students.get(0);
	        when(service.getStudent(anyInt())).thenReturn(cust);
	        Assert.assertEquals(studentController.showFormForUpdate(anyInt(), model),"student-form");
	        Assert.assertNotNull(model.get("student"));
	     //   Assert.assertTrue((Boolean)model.get("edit"));
	        Assert.assertEquals(((Student)model.get("student")).getId(), 3);
	    }
	    
	      	  @Test
	    	    public void deleteEmployee(){
	    	        doNothing().when(service).deleteStudent(anyInt());
	    	        Assert.assertEquals(studentController.deleteStudent(123), "redirect:/student/list");
	    	    }
	    
	    
		public List<Student> getStudentList() {
			Student c1 = new Student();
			Student c2 = new Student();
	        c1.setId(3);
	        c1.setFirstname("rajashekar");
	        c1.setLastname("sharma");
	        c1.setEmail("rajmatti@gmail.com");
	        
	        c2.setId(4);
	        c2.setFirstname("navin");
	        c2.setLastname("sharma");
	        c2.setEmail("navi@gmail.com");
	     
			students.add(c1);
			students.add(c2);
			
			return students;
		}

}
