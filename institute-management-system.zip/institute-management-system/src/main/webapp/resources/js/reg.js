function first_validate()
	{
        var firstname=document.getElementById("First_Name").value;
        
        var regex = /^[a-zA-Z ]*$/;
         if(firstname=="")
          {
            document.getElementById("fname").innerText="Enter First Name";
          }
          else{
            document.getElementById("fname").innerText="";
          }
            if(firstname.match(regex))
          {
          return true;
          }
          else
          {
            document.getElementById("fname").innerText="Invalid first Name";
          }
    }
	function last_validate()
	{
        var lastname=document.getElementById("Last_Name").value;
        
        var regex = /^[a-zA-Z ]*$/;
         if(lastname=="")
          {
            document.getElementById("lname").innerText="Enter Last Name"; 
          }
          else{
            document.getElementById("lname").innerText="";
          }
            if(lastname.match(regex))
          {
          return true;
          }
          else
          {
            document.getElementById("lname").innerText="Invalid Last Name";
          }
    }

    function email_validate()
    {
        var email=document.getElementById("email").value;
        var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if(email=="")
        {
          document.getElementById("mail").innerText="Enter E-Mail";
        }   
        else{
            document.getElementById("mail").innerText="";
          }
        if(email.match(mailformat))
        {
          return true;
        }
        else
        {
          document.getElementById("mail").innerText="Invalid Email!";
        }
    }
function pass_validate()
{
    var pass=document.getElementById("inputPassword4").value;
        if(pass.value=="")
        {
          document.getElementById("pas").innerText="please enter your password";
          return false;
            }
            else{
             document.getElementById("pas").innerText="";
            }
        if(pass.value.length<6)
        {
            document.getElementById("pas").innerText="password length should be greater than 6";
        }
        else{
            document.getElementById("pas").innerText="";
        }
}

function   con_validate()
{

    var pass1=document.forms['myForm']['inputPassword4'];
    var conpass1=document.forms['myForm']['confirmPassword'];
    if(conpass1.value=="")
	   {
         document.getElementById("cpas").innerText="please enter your password";
		 return false;
       }
       else{
        document.getElementById("cpas").innerText="";
    }
       if(pass1.value==conpass1.value)
       {
        document.getElementById("cpas").innerText="";
       }
       else
       {
        document.getElementById("cpas").innerText="password does not match";
       }

}
function contact_validate()
{
    var cont=document.forms['myForm']['inputPhoneNumber'];
    console.log("g  "+cont.value+" "+cont.value.length);
    if(cont.value.length<10)
	  {
      document.getElementById("phn").innerText="enter 10 digit number";
//return false;
      }
      else{
      document.getElementById("phn").innerText="";
      }
}
