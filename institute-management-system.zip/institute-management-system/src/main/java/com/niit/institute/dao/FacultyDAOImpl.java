package com.niit.institute.dao;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.institute.model.Faculty;
import com.niit.institute.model.Student;

@Repository
public class FacultyDAOImpl implements FacultyDAO {

	@Autowired
	SessionFactory sessionFactory;
	

	@Override
	public List<Faculty> getFacultys() {
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder cb = session.getCriteriaBuilder();
		CriteriaQuery<Faculty> cq = cb.createQuery(Faculty.class);
		Root<Faculty> root = cq.from(Faculty.class);
		cq.select(root);
		Query query = session.createQuery(cq);
		return query.getResultList();
	}

	@Override
	public void deleteFaculty(int id) {
		Session session = sessionFactory.getCurrentSession();
		Faculty book = session.byId(Faculty.class).load(id);
		session.delete(book);
	}

	@Override
	public void saveFaculty(Faculty theFaculty) {
		Session currentSession = sessionFactory.getCurrentSession();
		currentSession.saveOrUpdate(theFaculty);
	}

	@Override
	public Faculty getFaculty(int theId) {
		Session currentSession = sessionFactory.getCurrentSession();
		Faculty theFaculty = currentSession.get(Faculty.class, theId);
		return theFaculty;
	}
		
	@Override
	public Faculty checkFaculty(Faculty theFaculty) {
		Faculty usr=null;
		Session session=null;
		try {
		 session = sessionFactory.getCurrentSession();
		CriteriaBuilder cb = session.getCriteriaBuilder();
		CriteriaQuery<Faculty> cq = cb.createQuery(Faculty.class);
		Root<Faculty> root = cq.from(Faculty.class);
		cq.select(root).where(cb.and(
				cb.equal(root.get("email"), theFaculty.getEmail()),
				cb.equal(root.get("password"), theFaculty.getPassword())
			));
		
		Query query = session.createQuery(cq);
		query.setMaxResults(1);
		usr=(Faculty) query.getSingleResult();
		
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				//session.close();
			}
		}
		
		return usr;
	}
}
