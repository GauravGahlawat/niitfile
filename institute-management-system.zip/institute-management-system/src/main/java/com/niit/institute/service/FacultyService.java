package com.niit.institute.service;

import java.util.List;

import com.niit.institute.model.Faculty;
import com.niit.institute.model.Student;

public interface FacultyService {
	

	public List <Faculty> getFacultys();
	public void saveFaculty(Faculty theFaculty);
	public Faculty getFaculty(int theId);
	public void deleteFaculty(int theId);

	public Faculty checkFaculty(Faculty theFaculty);

}
