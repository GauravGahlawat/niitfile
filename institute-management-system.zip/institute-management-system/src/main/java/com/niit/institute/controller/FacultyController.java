package com.niit.institute.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.institute.model.Faculty;
import com.niit.institute.service.FacultyService;

@Controller
@RequestMapping("/faculty")
public class FacultyController {

	@Autowired
	private FacultyService facultyService;
	
	@GetMapping("/list")
	public String listFacultys(ModelMap theModel) {
		List<Faculty> theFacultys = facultyService.getFacultys();
		theModel.addAttribute("facultys", theFacultys);
		return "list-faculty";
	}
	
	@GetMapping("/showForm")
	public String showFormForAdd(ModelMap theModel) {
		Faculty theFaculty = new Faculty();
		theModel.addAttribute("faculty", theFaculty);
		return "faculty-form";
	}

	@PostMapping("/saveFaculty")
	public String saveFaculty(@ModelAttribute("faculty") Faculty theFaculty) {
		facultyService.saveFaculty(theFaculty);	
		return "redirect:/faculty/list";
	}
	
	@GetMapping("/updateForm")
	public String showFormForUpdate(@RequestParam("facultyId") int theId,
									ModelMap theModel) {
		Faculty theFaculty = facultyService.getFaculty(theId);	
		theModel.addAttribute("faculty", theFaculty);
		return "faculty-form";
	}
	
	@GetMapping("/delete")
	public String deleteFaculty(@RequestParam("facultyId") int theId) {
		facultyService.deleteFaculty(theId);
		return "redirect:/faculty/list";
	}

	@GetMapping("/loginForm")
	public String showFormForAdd(Model theModel) {
		Faculty theFaculty = new Faculty();
		theModel.addAttribute("faculty", theFaculty);
		return "login-faculty";
	}
	

	
	@RequestMapping(value = "/loginFaculty", method = RequestMethod.POST)
	public ModelAndView processLogin(@ModelAttribute Faculty theFaculty) {
		Faculty usr = facultyService.checkFaculty(theFaculty);
		ModelAndView model = null;
		if (usr == null) {
			model = new ModelAndView("login-faculty");
			model.addObject("error", "Invalid Username or Password");
		} else {
			model = new ModelAndView("welcome");
			model.addObject("usr", usr.getEmail());
		}
		return model;
	}
}
