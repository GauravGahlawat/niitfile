package com.niit.institute.dao;

import java.util.List;

import com.niit.institute.model.Faculty;

public interface FacultyDAO {
	

	public List <Faculty> getFacultys();
	public void saveFaculty(Faculty theFaculty);
	public Faculty getFaculty(int theId);
	public void deleteFaculty(int theId);
	public Faculty checkFaculty(Faculty theFaculty);

}
