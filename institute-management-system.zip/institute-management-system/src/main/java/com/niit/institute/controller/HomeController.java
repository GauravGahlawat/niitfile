package com.niit.institute.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class HomeController {

	@RequestMapping("/home")
	public String showHome()
	{
		return "home";
	}
	

	@GetMapping("/homepage")
	public String showHomePage() {
		return "index1";
	}
	

	@GetMapping("/about")
	public String showAboutUs() {
		return "about-us";
	}
	

	@GetMapping("/courses")
	public String showCourses() {
		return "courses";
	}
	

	@GetMapping("/contact")
	public String showContact() {
		return "contact";
	}
	

	@GetMapping("/studentsign")
	public String showSignUpStudent() {
		return "signupstudent";
	}
	

	@GetMapping("/facultysign")
	public String showSignUpFaculty() {
		return "signupfaculty";
	}
}
