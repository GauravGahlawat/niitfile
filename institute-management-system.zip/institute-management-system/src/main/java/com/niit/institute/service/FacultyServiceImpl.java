package com.niit.institute.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.institute.dao.FacultyDAO;
import com.niit.institute.model.Faculty;


@Service
public class FacultyServiceImpl implements FacultyService {

	
	  @Autowired 
	  private com.niit.institute.dao.FacultyDAO FacultyDAO;
	 
	

	@Autowired
	private FacultyDAO facultyDAO;
	
	@Override
	@Transactional
	public List<Faculty> getFacultys() {
		return facultyDAO.getFacultys();
	}

	@Override
	@Transactional
	public void saveFaculty(Faculty theFaculty) {
		facultyDAO.saveFaculty(theFaculty);
	}

	@Override
	@Transactional
	public Faculty getFaculty(int theId) {
		return facultyDAO.getFaculty(theId);
	}

	@Override
	@Transactional
	public void deleteFaculty(int theId) {
		facultyDAO.deleteFaculty(theId);
	}
	
	@Override
	@Transactional
	public Faculty checkFaculty(Faculty theFaculty) {
		return FacultyDAO.checkFaculty(theFaculty);	
	}

}
