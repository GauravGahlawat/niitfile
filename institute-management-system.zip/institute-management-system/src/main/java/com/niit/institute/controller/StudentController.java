package com.niit.institute.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.institute.model.Student;
import com.niit.institute.service.StudentService;

@Controller
@RequestMapping("/student")
public class StudentController {

	@Autowired
	private StudentService studentService;
	
	@GetMapping("/list")
	public String listStudents(ModelMap theModel) {
		List<Student> theStudents = studentService.getStudents();
		theModel.addAttribute("students", theStudents);
		return "list-students";
	}
	
	@GetMapping("/showForm")
	public String showFormForAdd(ModelMap theModel) {
		Student theStudent = new Student();
		theModel.addAttribute("student", theStudent);
		return "student-form";
	}
	
	
	
	
	@PostMapping("/saveStudent")
	public String saveStudent(@ModelAttribute("student") Student theStudent) {
		studentService.saveStudent(theStudent);	
		return "redirect:/student/list";
	}
	
	@GetMapping("/updateForm")
	public String showFormForUpdate(@RequestParam("studentId") int theId,
									ModelMap theModel) {
		Student theStudent = studentService.getStudent(theId);	
		theModel.addAttribute("student", theStudent);
		return "student-form";
	}
	
	@GetMapping("/delete")
	public String deleteStudent(@RequestParam("studentId") int theId) {
		studentService.deleteStudent(theId);
		return "redirect:/student/list";
	}
	
	
	@GetMapping("/loginForm")
	public String showFormForAdd(Model theModel) {
		Student theStudent = new Student();
		theModel.addAttribute("student", theStudent);
		return "login-student";
	}
	

	
	@RequestMapping(value = "/loginStudent", method = RequestMethod.POST)
	public ModelAndView processLogin(@ModelAttribute Student theStudent) {
		Student usr = studentService.checkStudent(theStudent);
		ModelAndView model = null;
		if (usr == null) {
			model = new ModelAndView("login-student");
			model.addObject("error", "Invalid Username or Password");
		} else {
			model = new ModelAndView("welcome");
			model.addObject("usr", usr.getEmail());
		}
		return model;
	}
}
